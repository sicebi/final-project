<?php 
session_start(); 
// include "../control/signup.php";
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<nav class="navbar navbar-inverse">
        <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="../index.php">Student Management System</a>
          </div>
        </div>
      </nav>
    </div>

<div class="container">
        <h1>Create Student Profile</h1>
        <h3 >Admin :<?php echo $_SESSION['username'] ; ?></h3>
        <div class="form-group">
            <form method="post" action="../control/profile.php" name="profileform">
                Admin :  <input type="text" class="form-control"  value=<?php echo $_SESSION['username'] ; ?>>
                StudentNo:<input type="text" class="form-control" placeholder="Enter StudentNo" name="studentnumber" tabindex="1" required>
                            <button type="submit" class="btn btn-default"  name="profile">Block/Unblock Student</button>
                            <button type="submit" class="btn btn-default"  name="profile">Delete Student</button>
                            <span><?php echo $_SESSION['error']; ?></span>
            </form> 
        </div>
    </div>