<?php 
session_start(); 
// include "../control/signup.php";
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<nav class="navbar navbar-inverse">
        <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="../index.php">Student Management System</a>
          </div>
        </div>
      </nav>
    </div>

<div class="container">
        <h1>Create Student Profile</h1>
        <h3 >Admin :<?php echo $_SESSION['username'] ; ?></h3>

        <div class="MainPhoto">
          <center><a href="edit_photo.php"><input class="btn btn-primary" type="submit" name="EditPhoto" value="Edit Photo" style="position: absolute; z-index: 9999999999999; left: 110px"></a></center>
            <img src="<?php echo "img\pp.jpg"; ?>" width="50%">
        </div>
        <div class="form-group">
            <form method="post" action="../control/createprofile.php" name="profileform">
                Username :  <input type="text" class="form-control" placeholder="Enter FullName" name="username" tabindex="1" required>
                Surname :   <input type="text" class="form-control" placeholder="Enter Surname" name="surname" tabindex="2" required>
                Email :     <input type="text" class="form-control" placeholder="Enter email" name="email" tabindex="3" required>
                CellNo:     <input type="text" class="form-control" placeholder="Enter cell No" name="contact" tabindex="4" required>
                Gender :     <select class="form-control" placeholder="Male/Female" name="gender" tabindex="5" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                              </select> 
                Qualification: <select name="qualification" class="form-control" placeholder="Enter Qualification" name="qualification" tabindex="6" required>
                                  <option value="DIT 1st Year">DIT 1st Year</option>
                                  <option value="DIT 2nd Year">DIT 2nd Year</option>
                                  <option value="DIT 3rd Year">DIT 3rd Year</option>
                                </select>
                StudentNo:<input type="text" class="form-control" placeholder="Enter StudentNo" name="studentnumber" tabindex="7" required>
                Password :  <input type="password" class="form-control" placeholder="Enter password" name="password" value="Student123" tabindex="8" required>
                            <button type="submit" class="btn btn-default"  name="createprofile">Create Profile</button>
                            <span><?php echo $_SESSION['error']; ?></span>
            </form> 
        </div>
    </div>