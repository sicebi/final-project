<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Student Management System</a>
          </div>
          <ul class="nav navbar-nav">
          <?php if (isset($_SESSION['username'])) { ?>
                <!-- Admin to add students  -->
                <li><a href="form/createprofile.php">Create Student</a></li>
                <li><a href="form/view.php">View Student</a></li>
                <li><a href="form/block_delete.php">Block/Delete Student</a></li>
                <li><a href="control/logout.php"><span class="glyphicon glyphicon-off"></span> LogOut</a></li>
            <?php }else{ ?>
              <h3><b>Welcome Back Admin</b></h3>
              <li><a href="form/login.php">Login</a></li>
              <li><a href="form/signup.php">Signup</a></li>
              <li><a href="form/reset.php">Reset</a></li>
            <?php } ?>
          </ul>
        </div>
      </nav>
    </div>
