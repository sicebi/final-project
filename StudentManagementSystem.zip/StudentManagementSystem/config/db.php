<?php
  $DB_DSN = 'mysql:host=localhost;dbname=StudentManagementSystem';
  $DB_USER = 'root';
  $DB_PASSWORD = '';
  $DB_NAME = 'StudentManagementSystem';
?>