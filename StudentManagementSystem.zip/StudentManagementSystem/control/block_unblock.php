<?php
session_start();
include '../config/db.php';


$Studentnumber = $_POST['studentnumber'];
//$hashkey = $_GET['hashkey'];
//$email = "advocate.ntini@gmail.com";
//$hashkey = "59b90e1005a220e2ebc542eb9d950b1e";
try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $req = $pdo->prepare('SELECT * FROM students WHERE studentnumber = ? AND state = ?' );
    $req->execute([$Studentnumber,'active']);
    $Existudent = $req->fetch();
} catch (PDOException $e) {
    echo 'Error: '.$e->getMessage();
    exit();
}

if ($Existudent){
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare("UPDATE students SET state = 'notactive' WHERE studentnumber = ? AND state = ?");
        $req->execute($Studentnumber,'active']);
    
    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        exit();
    }
    $_SESSION['error'] ="I you sure ? ";
    header("Location: ../form/block_delete.php");
}else{
    $_SESSION['error'] ="check link or contact your admin";
    header("Location: ../form/block_delete.php");
}

//unblock
try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $req = $pdo->prepare('SELECT * FROM students WHERE studentnumber = ? AND state = ?' );
    $req->execute([$Studentnumber,'notactive']);
    $Existudent_blocked = $req->fetch();
} catch (PDOException $e) {
    echo 'Error: '.$e->getMessage();
    exit();
}

if ($Existudent_blocked){
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare("UPDATE students SET state = 'active' WHERE studentnumber = ? AND state = ?");
        $req->execute($Studentnumber,'notactive']);
    
    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        exit();
    }
    $_SESSION['error'] ="I you sure ? ";
    header("Location: ../form/block_delete.php");
}else{
    $_SESSION['error'] ="check link or contact your admin";
    header("Location: ../form/block_delete.php");
}
?>