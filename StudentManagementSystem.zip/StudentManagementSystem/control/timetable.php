<?php

echo 'New Page now';
echo "<hr/><a href='../control/login_student.php'><button>back</button></a><hr>";


session_start();
include '../config/db.php';
//wiating to the data from URL

$module = $_GET['modules'];
$studentno = $_GET['studentno'];
$date = $_GET['date'];
$number = $_GET['number'];

$one =0;
$two = 0;
$three =0;
$four =0;

if ($number == "one"){
    $one = 1;
}elseif ($number == "two"){
    $two = 1;
}elseif ($number == "three"){
    $three = 1;
}elseif ($number == "four"){
    $four = 1;
}

// echo $module."   ".$studentno."        ".$date."  ***** " .$number;
try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $req = $pdo->prepare('SELECT * FROM timetable WHERE studentno = ? AND modulename = ? AND exactday = ?');
    $req->execute([$studentno, $module, $date]);
    $Existrecord = $req->fetch();
} catch (PDOException $e) {
    echo 'Error: '.$e->getMessage();
    exit();
}

if (!$Existrecord){
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare('INSERT INTO timetable SET studentno = ?,modulename = ?,exactday = ?,moduleone = ?,moduletwo = ?,modulethree = ?,modulefour = ?');
        $req->execute([$studentno, $module, $date, $one, $two, $three, $four]);
    
    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        exit();
    }
    $_SESSION['errortwo'] ="You have been added to the todays lecture see you in class";
    header("Location: ../index.php");
}else{
    $_SESSION['errortwo'] ="You already marked the register";
    header("Location: ../index.php");
}
?>