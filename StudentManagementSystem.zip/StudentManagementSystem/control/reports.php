<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    </head>
    <body>

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="../index.php">Student Management System</a>
          </div>
          </nav>

    </body>
</html>
<?php
session_start();
include '../config/db.php';
        
        

if (isset($_POST['Search'])) {
        
    $studentno= $_POST['studentNo'];

    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $req = $pdo->prepare("SELECT * FROM `timetable` WHERE studentno ='$studentno'");
        $req->execute();
        $studentNo = $req->fetchAll();
      } catch (PDOException $e) {
          echo 'Error: '.$e->getMessage();
          $_SESSION['error'] ="The Student not on database";
          header("Location: ../index.php");
          exit();
      }
    // echo $studentNo;

    $date = date('Y-m-d H:i:s');
    $Hour = substr($date, 11, -6);
    $minutes = substr($date, 14, -3);
    $day = substr($date, 0, -9);


    if ($studentNo){
        echo "<div class='well'>";
        echo"<h1>Student No : $studentno</h1>";
        foreach ($studentNo as $key => $studentNo) {
        
        echo "<table width='100%' border='3' cellspacing='0'";
        echo "<tr><th>Date</th><th>Module Name</th><th>1st Module</th><th>2nd Module</th><th>3rd Module</th><th>4th Module</th></tr>";
        echo "<tr><td>$studentNo[exactday]</td><td>$studentNo[modulename]</td><td>$studentNo[moduleone]</td><td>$studentNo[moduletwo]</td><td>$studentNo[modulethree]</td><td>$studentNo[modulefour]</td></tr>";
        echo "</table>";
        } 
        echo "</div>";

    }

    
}


?>