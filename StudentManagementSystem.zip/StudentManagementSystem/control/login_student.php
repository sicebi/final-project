<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    </head>
    <body>

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="../index.php">Student Management System</a>
          </div>
          </nav>

    </body>
</html>
<?php
session_start();
include '../config/db.php';
        
        

if (isset($_POST['Search'])) {
        
    $studentNo= $_POST['studentNo'];

    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $req = $pdo->prepare("SELECT * FROM `students` WHERE studentnumber ='$studentNo'");
        $req->execute();
        $modules = $req->fetchAll();
      } catch (PDOException $e) {
          echo 'Error: '.$e->getMessage();
          $_SESSION['error'] ="The use is not on database";
          header("Location: ../index.php");
          exit();
      }
    // echo $studentNo;

    $date = date('Y-m-d H:i:s');
    $Hour = substr($date, 11, -6);
    $minutes = substr($date, 14, -3);
    $day = substr($date, 0, -9);

    $mod1="";
    $mod2="";
    $mod3="";
    $mod4="";

    if ($modules) {
        echo "<div class='well'>";
        Echo "<h1>Welcome  on todays events <br/> $date ";
        foreach ($modules as $key => $modules) {
           
            
            if($Hour == 20 && $minutes >= 06){
                $mod1 = "disabled";
            }else if($Hour == 9 && $minutes >= 15){
                $mod2 = "disabled";
            }else if($Hour == 21){
                $mod3 = "disabled";
            }else if($Hour == 22){
                $mod4 = "disabled";
            }

            echo "<hr/><b>Module Name :</b>   <br/> $modules[moduleone]<br/> <a href='../control/timetable.php?modules=$modules[moduleone]&studentno=$studentNo&date=$day&number=one'><button $mod1>Accept</button></a><hr>";
            echo "<hr/><b>Module Name :</b>   <br/> $modules[moduletwo]<br/> <a href='../control/timetable.php?modules=$modules[moduletwo]&studentno=$studentNo&date=$day&number=two'><button $mod2>Accept</button></a><hr>";
            echo "<marquee behavior='scroll' direction='right'><hr/><b>Event Name :</b>   <br/> Meeting / Workshop <br/> <hr></marquee>";
            echo "<marquee behavior='scroll' direction='left'><hr/><b>Event Name :</b>   <br/> Lunch-Time <br/> <hr></marquee>";
            echo "<hr/><b>Module Name :</b>   <br/> $modules[modulethree]<br/> <a href='../control/timetable.php?modules=$modules[modulethree]&studentno=$studentNo&date=$day&number=three'><button $mod3>Accept</button></a><hr>";
            echo "<hr/><b>Module Name :</b>   <br/> $modules[modulefour]<br/> <a href='../control/timetable.php?modules=$modules[modulefour]&studentno=$studentNo&date=$day&number=four'><button $mod4>Accept</button></a><hr>";

        }
        echo '</div>';
    }
    echo '</div>';
}


?>