<?php
session_start();
include '../config/db.php';
if (isset($_POST['createprofile'])) {

    // $username= filter_var($_POST['username'], FILTER_SANITIZE_STRING);
    $admin = $_SESSION['username'];
    $username= $_POST['username'];
    $surname= $_POST['surname'];
    $email= $_POST['email'];
    $contact= $_POST['contact'];
    $gender = $_POST['gender'];
    $qualification = $_POST['qualification'];
    $studentNo = $_POST['studentnumber'];
    $password= $_POST['password'];
   

    $moduleone = "";$moduletwo = "";
    $modulethree = "";$modulefour = "";
   
    

    if($qualification == "DIT 1st Year") {
        $moduleone = "IS";$moduletwo = "Prog";
        $modulethree = "Web";$modulefour = "Net";

    }elseif ($qualification=="DIT 2nd Year"){
        $moduleone = "C++";$moduletwo = "PHP";
        $modulethree = "E-Commerce"; $modulefour="IS";

    }elseif($qualification == "DIT 3rd Year")
    {
        $moduleone = "OS";$moduletwo = "Java";
        $modulethree = "Statistics"; $modulefour="Software";

    }

    

    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare('SELECT username FROM students WHERE username = ?');
        $req->execute([$username]);
        $ExistUsername = $req->fetch();
    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        exit;
    }

    if ($ExistUsername)
    {
        $_SESSION['error'] ="Username Exist on Our DataBase";
        header("Location: ../form/createprofile.php");
        exit();    
    }
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare('SELECT studentnumber FROM students WHERE studentnumber = ?');
        $req->execute([$studentNo]);
        $$ExistStudentNumber = $req->fetch();
    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        exit;
    }

    if ($ExistStudentNumber)
    {
        $_SESSION['error'] ="Student Number exit on the system";
        header("Location: ../form/createprofile.php");
        exit();    
    }
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare('SELECT email FROM students WHERE email = ?');
        $req->execute([$email]);
        $ExistEmail = $req->fetch();
    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        exit;
    }
      
    if ($ExistEmail)
    {
        $_SESSION['error'] ="Email Exist on Our DataBase";
        header("Location: ../form/createprofile.php");
        exit();  
    }

    // generate hash and hash password
    $password = hash(SHA256, $password);

    echo $username.$surname.$studentNo.$qualification. $email.$contact. $password. "active".$admin.$moduleone.$moduletwo.$modulethree.$modulefour;
        
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = $pdo->prepare('INSERT INTO students SET username = ?,surname = ?,studentnumber = ?,qualification = ?, email = ?, contact = ?, password = ?, state = ?, admin = ?, moduleone = ?, moduletwo = ?, modulethree = ?, modulefour = ?');
        $req->execute([$username,$surname,$studentNo,$qualification, $email,$contact, $password, "active",$admin,$moduleone,$moduletwo,$modulethree,$modulefour]);

        //send email after wards

        $to = $email;
 		$subject = 'Student Management System | Profile Created';
  		$message = 'Good Day :'.$username. 'your profile has been created by '.$admin.' (admin) see your student number to the login.

  					------------------------
  					username: '.$username.'
                    StudentNo: '.$studentNo.'
                    Password: '.$password.'
  					------------------------

  					Click on the following link to Open the Student Management System
  					http://localhost/StudentManagementSystem/index.php';

  		$headers = 'From:'.$admin.'@richfield.com\r\n';
  		mail($to, $subject, $message, $headers);
        $_SESSION['error'] ="Student create profile successfully";
        header("Location: ../form/createprofile.php");
        exit();

    } catch (PDOException $e) {
        echo 'Error: '.$e->getMessage();
        $_SESSION['error'] ="Something went wrong admin";
        header("Location: ../form/createprofile.php");
        exit();
    }
}
?>