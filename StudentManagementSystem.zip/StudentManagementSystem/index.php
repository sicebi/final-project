<?php 
session_start(); 
unset ($_SESSION['error']);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Student Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-ico" href="favicon.ico">
   
 <!--Start bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!--End bootstrap -->
<link rel="stylesheet" type="text/css" href="css/css.css">
</head>
<body id="index">

    <?php if (isset($_SESSION['username'])) { ?>
        <?php require 'header/header.php'; ?>
    <div class="container">
        <h1 >Student Management System</h1>
            <h1>Student login</h1>
            <div class="form-group">
                <form method="post" action="control/reports.php" name="loginform">
                    StudentNo : <input type="text" class="form-control" placeholder="Enter Student Number" name="studentNo" tabindex="1" required>
                                <button type="submit" class="btn btn-default" name="Search" tabindex="3">Find Me</button> 
                                <div class="well"><?php echo $_SESSION['error']; ?></div>
                </form>
            </div>
    </div>
    <?php }else{ ?>
        <?php require 'header/header.php'; ?>
    <div class="container">
        <h1 >Student Management System</h1>
            <h1>Student login</h1>
            <div class="form-group">
                <form method="post" action="control/login_student.php" name="loginform">
                    StudentNo : <input type="text" class="form-control" placeholder="Enter Student Number" name="studentNo" tabindex="1" required>
                                <button type="submit" class="btn btn-default" name="Search" tabindex="3">Find Me</button> 
                                <div class="well"><?php echo $_SESSION['errortwo']; ?></div>
                </form>
            </div>
    </div>
    <?php } ?>


</body>
</html>